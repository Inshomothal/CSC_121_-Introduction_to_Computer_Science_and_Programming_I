/**
 * 
 */
/**
 * 
 */
module csc121.project05 {
	requires java.desktop;
}